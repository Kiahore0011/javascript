        // 4 verb type
        a = 10;
        let b = 20;
        const c = 10;
        var total = a + b - c;

        var m = document.getElementById("one")
        m.innerHTML = "The sum  is  --" + total;

        //  can also use "$" and "_num" AS verb

        let $$$ = 40;
        let _690 = 10;

        var n = document.getElementById("two")
        n.innerHTML = "The Ans " + ($$$ * _690);

        // Can also dec verb in oneline 
        let  name="manas", age="18" , en="409";
        document.getElementById("three").innerHTML  = name + " " + age + " " + en;

        // 4-

        const S = 10+2+3+15 ;
        document.getElementById("four").innerHTML = S;
        