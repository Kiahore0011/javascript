var n = document.getElementsByClassName("one");
n[0].innerHTML="no";
n[1].innerHTML="yes";


let m = document.getElementsByClassName("two");
m[0].innerHTML="no2";
m[1].innerHTML="yes2";

const o = document.getElementsByClassName("Three");
o[0].innerHTML="no3";
o[1].innerHTML="yes3";

