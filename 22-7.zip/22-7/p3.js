
const name =   prompt('Name');
document.write(name);

const age = prompt('Age')
document.write(age); 

const color = prompt('type any color name');
document.bgColor = color;

const a = alert("good")